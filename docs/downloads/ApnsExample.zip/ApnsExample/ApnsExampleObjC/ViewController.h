//
//  ViewController.h
//  ApnsExampleObjC
//
//  Created by Pranav Prakash on 14/03/16.
//  Copyright © 2016 Aurora Borialis. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface ViewController : UIViewController<CLLocationManagerDelegate>




@end

