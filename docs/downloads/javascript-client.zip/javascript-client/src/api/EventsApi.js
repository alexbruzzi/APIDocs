(function(root, factory) {
  if (typeof define === 'function' && define.amd) {
    // AMD. Register as an anonymous module.
    define(['../ApiClient', '../model/BeaconResponse', '../model/Message', '../model/Error', '../model/PageViewMessage', '../model/ProductPageViewMessage'], factory);
  } else if (typeof module === 'object' && module.exports) {
    // CommonJS-like environments that support module.exports, like Node.
    module.exports = factory(require('../ApiClient'), require('../model/BeaconResponse'), require('../model/Message'), require('../model/Error'), require('../model/PageViewMessage'), require('../model/ProductPageViewMessage'));
  } else {
    // Browser globals (root is window)
    if (!root.OctoEnterpriseApi) {
      root.OctoEnterpriseApi = {};
    }
    root.OctoEnterpriseApi.EventsApi = factory(root.OctoEnterpriseApi.ApiClient, root.OctoEnterpriseApi.BeaconResponse, root.OctoEnterpriseApi.Message, root.OctoEnterpriseApi.Error, root.OctoEnterpriseApi.PageViewMessage, root.OctoEnterpriseApi.ProductPageViewMessage);
  }
}(this, function(ApiClient, BeaconResponse, Message, Error, PageViewMessage, ProductPageViewMessage) {
  'use strict';

  var EventsApi = function EventsApi(apiClient) {
    this.apiClient = apiClient || ApiClient.default;

    var self = this;
    
    
    /**
     * Post an app init event.
     * Event fired when app is initiated. Everytime app comes to foreground, this event should be fired with all possible values.
     * @param {Message} body User ID
     * @param {function} callback the callback function, accepting three arguments: error, data, response
     *   data is of type: BeaconResponse
     */
    self.eventsAppInitPost = function(body, callback) {
      var postBody = body;
      
      // verify the required parameter 'body' is set
      if (body == null) {
        throw "Missing the required parameter 'body' when calling eventsAppInitPost";
      }
      

      var pathParams = {
      };
      var queryParams = {
      };
      var headerParams = {
      };
      var formParams = {
      };

      var authNames = ['apikey'];
      var contentTypes = ['application/json'];
      var accepts = ['application/json'];
      var returnType = BeaconResponse;

      return this.apiClient.callApi(
        '/events/app.init/', 'POST',
        pathParams, queryParams, headerParams, formParams, postBody,
        authNames, contentTypes, accepts, returnType, callback
      );

    }
    
    /**
     * Post an app login event.
     * Event fired when user logins to the app
     * @param {Message} body User ID
     * @param {function} callback the callback function, accepting three arguments: error, data, response
     *   data is of type: BeaconResponse
     */
    self.eventsAppLoginPost = function(body, callback) {
      var postBody = body;
      
      // verify the required parameter 'body' is set
      if (body == null) {
        throw "Missing the required parameter 'body' when calling eventsAppLoginPost";
      }
      

      var pathParams = {
      };
      var queryParams = {
      };
      var headerParams = {
      };
      var formParams = {
      };

      var authNames = ['apikey'];
      var contentTypes = ['application/json'];
      var accepts = ['application/json'];
      var returnType = BeaconResponse;

      return this.apiClient.callApi(
        '/events/app.login/', 'POST',
        pathParams, queryParams, headerParams, formParams, postBody,
        authNames, contentTypes, accepts, returnType, callback
      );

    }
    
    /**
     * Post an app logout event.
     * Event fired when user logs out of the app.
     * @param {Message} body User ID
     * @param {function} callback the callback function, accepting three arguments: error, data, response
     *   data is of type: BeaconResponse
     */
    self.eventsAppLogoutPost = function(body, callback) {
      var postBody = body;
      
      // verify the required parameter 'body' is set
      if (body == null) {
        throw "Missing the required parameter 'body' when calling eventsAppLogoutPost";
      }
      

      var pathParams = {
      };
      var queryParams = {
      };
      var headerParams = {
      };
      var formParams = {
      };

      var authNames = ['apikey'];
      var contentTypes = ['application/json'];
      var accepts = ['application/json'];
      var returnType = BeaconResponse;

      return this.apiClient.callApi(
        '/events/app.logout/', 'POST',
        pathParams, queryParams, headerParams, formParams, postBody,
        authNames, contentTypes, accepts, returnType, callback
      );

    }
    
    /**
     * Post a page view event.
     * Event fired when a page view happened. You should fire this event on every page change in the viewport
     * @param {PageViewMessage} body Page View Message
     * @param {function} callback the callback function, accepting three arguments: error, data, response
     *   data is of type: BeaconResponse
     */
    self.eventsPageViewPost = function(body, callback) {
      var postBody = body;
      
      // verify the required parameter 'body' is set
      if (body == null) {
        throw "Missing the required parameter 'body' when calling eventsPageViewPost";
      }
      

      var pathParams = {
      };
      var queryParams = {
      };
      var headerParams = {
      };
      var formParams = {
      };

      var authNames = ['apikey'];
      var contentTypes = ['application/json'];
      var accepts = ['application/json'];
      var returnType = BeaconResponse;

      return this.apiClient.callApi(
        '/events/page.view/', 'POST',
        pathParams, queryParams, headerParams, formParams, postBody,
        authNames, contentTypes, accepts, returnType, callback
      );

    }
    
    /**
     * Post a product page view event.
     * Event fired when a product page view happened. You should fire this event on every page change in the viewport for products. Products are anything that the consumer consumes. It could cost them money or time. This cost is the value of &#39;price&#39; parameter.
     * @param {ProductPageViewMessage} body User ID
     * @param {function} callback the callback function, accepting three arguments: error, data, response
     *   data is of type: BeaconResponse
     */
    self.eventsProductpageViewPost = function(body, callback) {
      var postBody = body;
      
      // verify the required parameter 'body' is set
      if (body == null) {
        throw "Missing the required parameter 'body' when calling eventsProductpageViewPost";
      }
      

      var pathParams = {
      };
      var queryParams = {
      };
      var headerParams = {
      };
      var formParams = {
      };

      var authNames = ['apikey'];
      var contentTypes = ['application/json'];
      var accepts = ['application/json'];
      var returnType = BeaconResponse;

      return this.apiClient.callApi(
        '/events/productpage.view/', 'POST',
        pathParams, queryParams, headerParams, formParams, postBody,
        authNames, contentTypes, accepts, returnType, callback
      );

    }
    
    
  };

  return EventsApi;
}));
