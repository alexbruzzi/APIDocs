(function(root, factory) {
  if (typeof define === 'function' && define.amd) {
    // AMD. Register as an anonymous module.
    define(['../ApiClient', '../model/BeaconResponse', '../model/Error', '../model/UpdatePushToken'], factory);
  } else if (typeof module === 'object' && module.exports) {
    // CommonJS-like environments that support module.exports, like Node.
    module.exports = factory(require('../ApiClient'), require('../model/BeaconResponse'), require('../model/Error'), require('../model/UpdatePushToken'));
  } else {
    // Browser globals (root is window)
    if (!root.OctoEnterpriseApi) {
      root.OctoEnterpriseApi = {};
    }
    root.OctoEnterpriseApi.PushnotificationApi = factory(root.OctoEnterpriseApi.ApiClient, root.OctoEnterpriseApi.BeaconResponse, root.OctoEnterpriseApi.Error, root.OctoEnterpriseApi.UpdatePushToken);
  }
}(this, function(ApiClient, BeaconResponse, Error, UpdatePushToken) {
  'use strict';

  var PushnotificationApi = function PushnotificationApi(apiClient) {
    this.apiClient = apiClient || ApiClient.default;

    var self = this;
    
    
    /**
     * Update push token for a user device.
     * Use this to update the tokens necessary for push notifications. This is exposed as a set of 3 attributes - notification type, push token and push key. Notification type should be 0 for iOS notification and 1 for android. Push token could be the GCM registration token or the APNS registration token for the app device. Push key is your app&#39;s GCM key or APN key. Userid is optional. If userid is not speficied, the gcm token is stored without a userid. If a userid gets updated for a gcm token in future, another call needs to be made mentioning the userid.
     * @param {UpdatePushToken} body JSON object containing data
     * @param {function} callback the callback function, accepting three arguments: error, data, response
     *   data is of type: BeaconResponse
     */
    self.updatePushTokenPost = function(body, callback) {
      var postBody = body;
      
      // verify the required parameter 'body' is set
      if (body == null) {
        throw "Missing the required parameter 'body' when calling updatePushTokenPost";
      }
      

      var pathParams = {
      };
      var queryParams = {
      };
      var headerParams = {
      };
      var formParams = {
      };

      var authNames = ['apikey'];
      var contentTypes = ['application/json'];
      var accepts = ['application/json'];
      var returnType = BeaconResponse;

      return this.apiClient.callApi(
        '/update_push_token/', 'POST',
        pathParams, queryParams, headerParams, formParams, postBody,
        authNames, contentTypes, accepts, returnType, callback
      );

    }
    
    
  };

  return PushnotificationApi;
}));
