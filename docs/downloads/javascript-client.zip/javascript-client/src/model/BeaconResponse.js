(function(root, factory) {
  if (typeof define === 'function' && define.amd) {
    // AMD. Register as an anonymous module.
    define(['../ApiClient'], factory);
  } else if (typeof module === 'object' && module.exports) {
    // CommonJS-like environments that support module.exports, like Node.
    module.exports = factory(require('../ApiClient'));
  } else {
    // Browser globals (root is window)
    if (!root.OctoEnterpriseApi) {
      root.OctoEnterpriseApi = {};
    }
    root.OctoEnterpriseApi.BeaconResponse = factory(root.OctoEnterpriseApi.ApiClient);
  }
}(this, function(ApiClient) {
  'use strict';
  
  /**
   * Beacon response model
   **/
  var BeaconResponse = function BeaconResponse() { 
    
  };

  BeaconResponse.constructFromObject = function(data) {
    if (!data) {
      return null;
    }
    var _this = new BeaconResponse();
    
    if (data['eventId']) {
      _this['eventId'] = ApiClient.convertToType(data['eventId'], 'String');
    }
    
    return _this;
  }

  
  
  /**
   * get The UUID of the event. Use this to trace the event
   * @return {String}
   **/
  BeaconResponse.prototype.getEventId = function() {
    return this['eventId'];
  }

  /**
   * set The UUID of the event. Use this to trace the event
   * @param {String} eventId
   **/
  BeaconResponse.prototype.setEventId = function(eventId) {
    this['eventId'] = eventId;
  }
  
  

  

  return BeaconResponse;
  
  
}));
