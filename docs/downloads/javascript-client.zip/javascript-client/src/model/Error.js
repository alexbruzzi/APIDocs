(function(root, factory) {
  if (typeof define === 'function' && define.amd) {
    // AMD. Register as an anonymous module.
    define(['../ApiClient'], factory);
  } else if (typeof module === 'object' && module.exports) {
    // CommonJS-like environments that support module.exports, like Node.
    module.exports = factory(require('../ApiClient'));
  } else {
    // Browser globals (root is window)
    if (!root.OctoEnterpriseApi) {
      root.OctoEnterpriseApi = {};
    }
    root.OctoEnterpriseApi.Error = factory(root.OctoEnterpriseApi.ApiClient);
  }
}(this, function(ApiClient) {
  'use strict';
  
  /**
   * Error model
   **/
  var Error = function Error() { 
    
  };

  Error.constructFromObject = function(data) {
    if (!data) {
      return null;
    }
    var _this = new Error();
    
    if (data['code']) {
      _this['code'] = ApiClient.convertToType(data['code'], 'Integer');
    }
    
    if (data['message']) {
      _this['message'] = ApiClient.convertToType(data['message'], 'String');
    }
    
    return _this;
  }

  
  
  /**
   * @return {Integer}
   **/
  Error.prototype.getCode = function() {
    return this['code'];
  }

  /**
   * @param {Integer} code
   **/
  Error.prototype.setCode = function(code) {
    this['code'] = code;
  }
  
  /**
   * @return {String}
   **/
  Error.prototype.getMessage = function() {
    return this['message'];
  }

  /**
   * @param {String} message
   **/
  Error.prototype.setMessage = function(message) {
    this['message'] = message;
  }
  
  

  

  return Error;
  
  
}));
