(function(root, factory) {
  if (typeof define === 'function' && define.amd) {
    // AMD. Register as an anonymous module.
    define(['../ApiClient', './PhoneDetails'], factory);
  } else if (typeof module === 'object' && module.exports) {
    // CommonJS-like environments that support module.exports, like Node.
    module.exports = factory(require('../ApiClient'), require('./PhoneDetails'));
  } else {
    // Browser globals (root is window)
    if (!root.OctoEnterpriseApi) {
      root.OctoEnterpriseApi = {};
    }
    root.OctoEnterpriseApi.Message = factory(root.OctoEnterpriseApi.ApiClient, root.OctoEnterpriseApi.PhoneDetails);
  }
}(this, function(ApiClient, PhoneDetails) {
  'use strict';
  
  /**
   * Base message model. Every message must belong to this model
   **/
  var Message = function Message(userIdphoneDetails, ) { 
    
    /**
     * Unique User Id of the logged in user. Any unique tracking ID for logged out user.
     * datatype: Integer
     * required 
     **/
    this['userId'] = userId;
    /**
     * datatype: PhoneDetails
     * required 
     **/
    this['phoneDetails'] = phoneDetails;
  };

  Message.constructFromObject = function(data) {
    if (!data) {
      return null;
    }
    var _this = new Message();
    
    if (data['userId']) {
      _this['userId'] = ApiClient.convertToType(data['userId'], 'Integer');
    }
    
    if (data['phoneDetails']) {
      _this['phoneDetails'] = PhoneDetails.constructFromObject(data['phoneDetails']);
    }
    
    return _this;
  }

  
  
  /**
   * get Unique User Id of the logged in user. Any unique tracking ID for logged out user.
   * @return {Integer}
   **/
  Message.prototype.getUserId = function() {
    return this['userId'];
  }

  /**
   * set Unique User Id of the logged in user. Any unique tracking ID for logged out user.
   * @param {Integer} userId
   **/
  Message.prototype.setUserId = function(userId) {
    this['userId'] = userId;
  }
  
  /**
   * @return {PhoneDetails}
   **/
  Message.prototype.getPhoneDetails = function() {
    return this['phoneDetails'];
  }

  /**
   * @param {PhoneDetails} phoneDetails
   **/
  Message.prototype.setPhoneDetails = function(phoneDetails) {
    this['phoneDetails'] = phoneDetails;
  }
  
  

  

  return Message;
  
  
}));
