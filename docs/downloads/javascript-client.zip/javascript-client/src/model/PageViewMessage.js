(function(root, factory) {
  if (typeof define === 'function' && define.amd) {
    // AMD. Register as an anonymous module.
    define(['../ApiClient', './Message', './PhoneDetails'], factory);
  } else if (typeof module === 'object' && module.exports) {
    // CommonJS-like environments that support module.exports, like Node.
    module.exports = factory(require('../ApiClient'), require('./Message'), require('./PhoneDetails'));
  } else {
    // Browser globals (root is window)
    if (!root.OctoEnterpriseApi) {
      root.OctoEnterpriseApi = {};
    }
    root.OctoEnterpriseApi.PageViewMessage = factory(root.OctoEnterpriseApi.ApiClient, root.OctoEnterpriseApi.Message, root.OctoEnterpriseApi.PhoneDetails);
  }
}(this, function(ApiClient, Message, PhoneDetails) {
  'use strict';
  
  /**
   * Model for page view message
   **/
  var PageViewMessage = function PageViewMessage(phoneDetails, routeUrl, userId) { /* extends Message*/
    
    /**
     * datatype: PhoneDetails
     * required 
     **/
    this['phoneDetails'] = phoneDetails;
    /**
     * Human readable unique routing Url for the page
     * datatype: String
     * required 
     **/
    this['routeUrl'] = routeUrl;
    /**
     * Unique User Id of the logged in user. Any unique tracking ID for logged out user.
     * datatype: Integer
     * required 
     **/
    this['userId'] = userId;
  };

  PageViewMessage.constructFromObject = function(data) {
    if (!data) {
      return null;
    }
    var _this = new PageViewMessage();
    
    if (data['categories']) {
      _this['categories'] = ApiClient.convertToType(data['categories'], ['String']);
    }
    
    if (data['phoneDetails']) {
      _this['phoneDetails'] = PhoneDetails.constructFromObject(data['phoneDetails']);
    }
    
    if (data['routeUrl']) {
      _this['routeUrl'] = ApiClient.convertToType(data['routeUrl'], 'String');
    }
    
    if (data['userId']) {
      _this['userId'] = ApiClient.convertToType(data['userId'], 'Integer');
    }
    
    if (data['tags']) {
      _this['tags'] = ApiClient.convertToType(data['tags'], ['String']);
    }
    
    return _this;
  }

  
  
  /**
   * @return {[String]}
   **/
  PageViewMessage.prototype.getCategories = function() {
    return this['categories'];
  }

  /**
   * @param {[String]} categories
   **/
  PageViewMessage.prototype.setCategories = function(categories) {
    this['categories'] = categories;
  }
  
  /**
   * @return {PhoneDetails}
   **/
  PageViewMessage.prototype.getPhoneDetails = function() {
    return this['phoneDetails'];
  }

  /**
   * @param {PhoneDetails} phoneDetails
   **/
  PageViewMessage.prototype.setPhoneDetails = function(phoneDetails) {
    this['phoneDetails'] = phoneDetails;
  }
  
  /**
   * get Human readable unique routing Url for the page
   * @return {String}
   **/
  PageViewMessage.prototype.getRouteUrl = function() {
    return this['routeUrl'];
  }

  /**
   * set Human readable unique routing Url for the page
   * @param {String} routeUrl
   **/
  PageViewMessage.prototype.setRouteUrl = function(routeUrl) {
    this['routeUrl'] = routeUrl;
  }
  
  /**
   * get Unique User Id of the logged in user. Any unique tracking ID for logged out user.
   * @return {Integer}
   **/
  PageViewMessage.prototype.getUserId = function() {
    return this['userId'];
  }

  /**
   * set Unique User Id of the logged in user. Any unique tracking ID for logged out user.
   * @param {Integer} userId
   **/
  PageViewMessage.prototype.setUserId = function(userId) {
    this['userId'] = userId;
  }
  
  /**
   * @return {[String]}
   **/
  PageViewMessage.prototype.getTags = function() {
    return this['tags'];
  }

  /**
   * @param {[String]} tags
   **/
  PageViewMessage.prototype.setTags = function(tags) {
    this['tags'] = tags;
  }
  
  

  

  return PageViewMessage;
  
  
}));
