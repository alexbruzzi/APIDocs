(function(root, factory) {
  if (typeof define === 'function' && define.amd) {
    // AMD. Register as an anonymous module.
    define(['../ApiClient'], factory);
  } else if (typeof module === 'object' && module.exports) {
    // CommonJS-like environments that support module.exports, like Node.
    module.exports = factory(require('../ApiClient'));
  } else {
    // Browser globals (root is window)
    if (!root.OctoEnterpriseApi) {
      root.OctoEnterpriseApi = {};
    }
    root.OctoEnterpriseApi.PhoneDetails = factory(root.OctoEnterpriseApi.ApiClient);
  }
}(this, function(ApiClient) {
  'use strict';
  
  /**
   * Model for phone details of the user
   **/
  var PhoneDetails = function PhoneDetails() { 
    
  };

  PhoneDetails.constructFromObject = function(data) {
    if (!data) {
      return null;
    }
    var _this = new PhoneDetails();
    
    if (data['deviceId']) {
      _this['deviceId'] = ApiClient.convertToType(data['deviceId'], 'String');
    }
    
    if (data['manufacturer']) {
      _this['manufacturer'] = ApiClient.convertToType(data['manufacturer'], 'String');
    }
    
    if (data['model']) {
      _this['model'] = ApiClient.convertToType(data['model'], 'String');
    }
    
    if (data['latitude']) {
      _this['latitude'] = ApiClient.convertToType(data['latitude'], 'Number');
    }
    
    if (data['longitude']) {
      _this['longitude'] = ApiClient.convertToType(data['longitude'], 'Number');
    }
    
    return _this;
  }

  
  
  /**
   * @return {String}
   **/
  PhoneDetails.prototype.getDeviceId = function() {
    return this['deviceId'];
  }

  /**
   * @param {String} deviceId
   **/
  PhoneDetails.prototype.setDeviceId = function(deviceId) {
    this['deviceId'] = deviceId;
  }
  
  /**
   * @return {String}
   **/
  PhoneDetails.prototype.getManufacturer = function() {
    return this['manufacturer'];
  }

  /**
   * @param {String} manufacturer
   **/
  PhoneDetails.prototype.setManufacturer = function(manufacturer) {
    this['manufacturer'] = manufacturer;
  }
  
  /**
   * @return {String}
   **/
  PhoneDetails.prototype.getModel = function() {
    return this['model'];
  }

  /**
   * @param {String} model
   **/
  PhoneDetails.prototype.setModel = function(model) {
    this['model'] = model;
  }
  
  /**
   * @return {Number}
   **/
  PhoneDetails.prototype.getLatitude = function() {
    return this['latitude'];
  }

  /**
   * @param {Number} latitude
   **/
  PhoneDetails.prototype.setLatitude = function(latitude) {
    this['latitude'] = latitude;
  }
  
  /**
   * @return {Number}
   **/
  PhoneDetails.prototype.getLongitude = function() {
    return this['longitude'];
  }

  /**
   * @param {Number} longitude
   **/
  PhoneDetails.prototype.setLongitude = function(longitude) {
    this['longitude'] = longitude;
  }
  
  

  

  return PhoneDetails;
  
  
}));
