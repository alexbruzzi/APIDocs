(function(root, factory) {
  if (typeof define === 'function' && define.amd) {
    // AMD. Register as an anonymous module.
    define(['../ApiClient', './PageViewMessage'], factory);
  } else if (typeof module === 'object' && module.exports) {
    // CommonJS-like environments that support module.exports, like Node.
    module.exports = factory(require('../ApiClient'), require('./PageViewMessage'));
  } else {
    // Browser globals (root is window)
    if (!root.OctoEnterpriseApi) {
      root.OctoEnterpriseApi = {};
    }
    root.OctoEnterpriseApi.ProductPageViewMessage = factory(root.OctoEnterpriseApi.ApiClient, root.OctoEnterpriseApi.PageViewMessage);
  }
}(this, function(ApiClient, PageViewMessage) {
  'use strict';
  
  /**
   * Model for product page view
   **/
  var ProductPageViewMessage = function ProductPageViewMessage(productId, productName, price) { /* extends PageViewMessage*/
    
    /**
     * Unique Product ID of the product being viewed
     * datatype: Integer
     * required 
     **/
    this['productId'] = productId;
    /**
     * Human understandable name of the product
     * datatype: String
     * required 
     **/
    this['productName'] = productName;
    /**
     * Price of the product
     * datatype: Number
     * required 
     **/
    this['price'] = price;
  };

  ProductPageViewMessage.constructFromObject = function(data) {
    if (!data) {
      return null;
    }
    var _this = new ProductPageViewMessage();
    
    if (data['productId']) {
      _this['productId'] = ApiClient.convertToType(data['productId'], 'Integer');
    }
    
    if (data['productName']) {
      _this['productName'] = ApiClient.convertToType(data['productName'], 'String');
    }
    
    if (data['price']) {
      _this['price'] = ApiClient.convertToType(data['price'], 'Number');
    }
    
    return _this;
  }

  
  
  /**
   * get Unique Product ID of the product being viewed
   * @return {Integer}
   **/
  ProductPageViewMessage.prototype.getProductId = function() {
    return this['productId'];
  }

  /**
   * set Unique Product ID of the product being viewed
   * @param {Integer} productId
   **/
  ProductPageViewMessage.prototype.setProductId = function(productId) {
    this['productId'] = productId;
  }
  
  /**
   * get Human understandable name of the product
   * @return {String}
   **/
  ProductPageViewMessage.prototype.getProductName = function() {
    return this['productName'];
  }

  /**
   * set Human understandable name of the product
   * @param {String} productName
   **/
  ProductPageViewMessage.prototype.setProductName = function(productName) {
    this['productName'] = productName;
  }
  
  /**
   * get Price of the product
   * @return {Number}
   **/
  ProductPageViewMessage.prototype.getPrice = function() {
    return this['price'];
  }

  /**
   * set Price of the product
   * @param {Number} price
   **/
  ProductPageViewMessage.prototype.setPrice = function(price) {
    this['price'] = price;
  }
  
  

  

  return ProductPageViewMessage;
  
  
}));
