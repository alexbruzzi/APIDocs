(function(root, factory) {
  if (typeof define === 'function' && define.amd) {
    // AMD. Register as an anonymous module.
    define(['../ApiClient', './PhoneDetails'], factory);
  } else if (typeof module === 'object' && module.exports) {
    // CommonJS-like environments that support module.exports, like Node.
    module.exports = factory(require('../ApiClient'), require('./PhoneDetails'));
  } else {
    // Browser globals (root is window)
    if (!root.OctoEnterpriseApi) {
      root.OctoEnterpriseApi = {};
    }
    root.OctoEnterpriseApi.UpdatePushToken = factory(root.OctoEnterpriseApi.ApiClient, root.OctoEnterpriseApi.PhoneDetails);
  }
}(this, function(ApiClient, PhoneDetails) {
  'use strict';
  
  /**
   * Model for update push token message
   **/
  var UpdatePushToken = function UpdatePushToken(pushToken, notificationType, phoneDetails) { 
    
    /**
     * Push Token for the user-device. This could be either the GCM Token or the APN Token
     * datatype: String
     * required 
     **/
    this['pushToken'] = pushToken;
    /**
     * Set this to 1 for Android and 0 for iOS
     * datatype: Integer
     * required 
     **/
    this['notificationType'] = notificationType;
    /**
     * datatype: PhoneDetails
     * required 
     **/
    this['phoneDetails'] = phoneDetails;
  };

  UpdatePushToken.constructFromObject = function(data) {
    if (!data) {
      return null;
    }
    var _this = new UpdatePushToken();
    
    if (data['userId']) {
      _this['userId'] = ApiClient.convertToType(data['userId'], 'Integer');
    }
    
    if (data['pushToken']) {
      _this['pushToken'] = ApiClient.convertToType(data['pushToken'], 'String');
    }
    
    if (data['pushKey']) {
      _this['pushKey'] = ApiClient.convertToType(data['pushKey'], 'String');
    }
    
    if (data['notificationType']) {
      _this['notificationType'] = ApiClient.convertToType(data['notificationType'], 'Integer');
    }
    
    if (data['phoneDetails']) {
      _this['phoneDetails'] = PhoneDetails.constructFromObject(data['phoneDetails']);
    }
    
    return _this;
  }

  
  
  /**
   * get Unique User Id of the user.
   * @return {Integer}
   **/
  UpdatePushToken.prototype.getUserId = function() {
    return this['userId'];
  }

  /**
   * set Unique User Id of the user.
   * @param {Integer} userId
   **/
  UpdatePushToken.prototype.setUserId = function(userId) {
    this['userId'] = userId;
  }
  
  /**
   * get Push Token for the user-device. This could be either the GCM Token or the APN Token
   * @return {String}
   **/
  UpdatePushToken.prototype.getPushToken = function() {
    return this['pushToken'];
  }

  /**
   * set Push Token for the user-device. This could be either the GCM Token or the APN Token
   * @param {String} pushToken
   **/
  UpdatePushToken.prototype.setPushToken = function(pushToken) {
    this['pushToken'] = pushToken;
  }
  
  /**
   * get Your app's push notification key. This could be either your app's GCM key or your app's APN key.
   * @return {String}
   **/
  UpdatePushToken.prototype.getPushKey = function() {
    return this['pushKey'];
  }

  /**
   * set Your app's push notification key. This could be either your app's GCM key or your app's APN key.
   * @param {String} pushKey
   **/
  UpdatePushToken.prototype.setPushKey = function(pushKey) {
    this['pushKey'] = pushKey;
  }
  
  /**
   * get Set this to 1 for Android and 0 for iOS
   * @return {Integer}
   **/
  UpdatePushToken.prototype.getNotificationType = function() {
    return this['notificationType'];
  }

  /**
   * set Set this to 1 for Android and 0 for iOS
   * @param {Integer} notificationType
   **/
  UpdatePushToken.prototype.setNotificationType = function(notificationType) {
    this['notificationType'] = notificationType;
  }
  
  /**
   * @return {PhoneDetails}
   **/
  UpdatePushToken.prototype.getPhoneDetails = function() {
    return this['phoneDetails'];
  }

  /**
   * @param {PhoneDetails} phoneDetails
   **/
  UpdatePushToken.prototype.setPhoneDetails = function(phoneDetails) {
    this['phoneDetails'] = phoneDetails;
  }
  
  

  

  return UpdatePushToken;
  
  
}));
