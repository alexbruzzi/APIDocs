# SwaggerClient::BeaconResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**event_id** | **String** | The UUID of the event. Use this to trace the event | [optional] 


