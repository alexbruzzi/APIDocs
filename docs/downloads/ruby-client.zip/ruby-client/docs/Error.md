# SwaggerClient::Error

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **Integer** |  | [optional] 
**message** | **String** |  | [optional] 


