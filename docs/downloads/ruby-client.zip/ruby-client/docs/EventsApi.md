# SwaggerClient::EventsApi

All URIs are relative to *http://127.0.0.1:8000/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**events_app_init_post**](EventsApi.md#events_app_init_post) | **POST** /events/app.init/ | Post an app init event.
[**events_app_login_post**](EventsApi.md#events_app_login_post) | **POST** /events/app.login/ | Post an app login event.
[**events_app_logout_post**](EventsApi.md#events_app_logout_post) | **POST** /events/app.logout/ | Post an app logout event.
[**events_page_view_post**](EventsApi.md#events_page_view_post) | **POST** /events/page.view/ | Post a page view event.
[**events_productpage_view_post**](EventsApi.md#events_productpage_view_post) | **POST** /events/productpage.view/ | Post a product page view event.


# **events_app_init_post**
> BeaconResponse events_app_init_post(body)

Post an app init event.

Event fired when app is initiated. Everytime app comes to foreground, this event should be fired with all possible values.

### Example
```ruby
require 'swagger_client'

SwaggerClient.configure do |config|
  # Configure API key authorization: apikey
  config.api_key['apikey'] = "YOUR API KEY"
  # Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to nil)
  #config.api_key_prefix['apikey'] = "Token"
end

api = SwaggerClient::EventsApi.new

body = SwaggerClient::Message.new # [Message] User ID


begin
  result = api.events_app_init_post(body)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling events_app_init_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Message**](Message.md)| User ID | 

### Return type

[**BeaconResponse**](BeaconResponse.md)

### Authorization

[apikey](../README.md#apikey)

### HTTP reuqest headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **events_app_login_post**
> BeaconResponse events_app_login_post(body)

Post an app login event.

Event fired when user logins to the app

### Example
```ruby
require 'swagger_client'

SwaggerClient.configure do |config|
  # Configure API key authorization: apikey
  config.api_key['apikey'] = "YOUR API KEY"
  # Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to nil)
  #config.api_key_prefix['apikey'] = "Token"
end

api = SwaggerClient::EventsApi.new

body = SwaggerClient::Message.new # [Message] User ID


begin
  result = api.events_app_login_post(body)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling events_app_login_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Message**](Message.md)| User ID | 

### Return type

[**BeaconResponse**](BeaconResponse.md)

### Authorization

[apikey](../README.md#apikey)

### HTTP reuqest headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **events_app_logout_post**
> BeaconResponse events_app_logout_post(body)

Post an app logout event.

Event fired when user logs out of the app.

### Example
```ruby
require 'swagger_client'

SwaggerClient.configure do |config|
  # Configure API key authorization: apikey
  config.api_key['apikey'] = "YOUR API KEY"
  # Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to nil)
  #config.api_key_prefix['apikey'] = "Token"
end

api = SwaggerClient::EventsApi.new

body = SwaggerClient::Message.new # [Message] User ID


begin
  result = api.events_app_logout_post(body)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling events_app_logout_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Message**](Message.md)| User ID | 

### Return type

[**BeaconResponse**](BeaconResponse.md)

### Authorization

[apikey](../README.md#apikey)

### HTTP reuqest headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **events_page_view_post**
> BeaconResponse events_page_view_post(body)

Post a page view event.

Event fired when a page view happened. You should fire this event on every page change in the viewport

### Example
```ruby
require 'swagger_client'

SwaggerClient.configure do |config|
  # Configure API key authorization: apikey
  config.api_key['apikey'] = "YOUR API KEY"
  # Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to nil)
  #config.api_key_prefix['apikey'] = "Token"
end

api = SwaggerClient::EventsApi.new

body = SwaggerClient::PageViewMessage.new # [PageViewMessage] Page View Message


begin
  result = api.events_page_view_post(body)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling events_page_view_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**PageViewMessage**](PageViewMessage.md)| Page View Message | 

### Return type

[**BeaconResponse**](BeaconResponse.md)

### Authorization

[apikey](../README.md#apikey)

### HTTP reuqest headers

 - **Content-Type**: application/json
 - **Accept**: application/json



# **events_productpage_view_post**
> BeaconResponse events_productpage_view_post(body)

Post a product page view event.

Event fired when a product page view happened. You should fire this event on every page change in the viewport for products. Products are anything that the consumer consumes. It could cost them money or time. This cost is the value of &#39;price&#39; parameter.

### Example
```ruby
require 'swagger_client'

SwaggerClient.configure do |config|
  # Configure API key authorization: apikey
  config.api_key['apikey'] = "YOUR API KEY"
  # Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to nil)
  #config.api_key_prefix['apikey'] = "Token"
end

api = SwaggerClient::EventsApi.new

body = SwaggerClient::ProductPageViewMessage.new # [ProductPageViewMessage] User ID


begin
  result = api.events_productpage_view_post(body)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling events_productpage_view_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**ProductPageViewMessage**](ProductPageViewMessage.md)| User ID | 

### Return type

[**BeaconResponse**](BeaconResponse.md)

### Authorization

[apikey](../README.md#apikey)

### HTTP reuqest headers

 - **Content-Type**: application/json
 - **Accept**: application/json



