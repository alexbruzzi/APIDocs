# SwaggerClient::Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**user_id** | **Integer** | Unique User Id of the logged in user. Any unique tracking ID for logged out user. | 
**phone_details** | [**PhoneDetails**](PhoneDetails.md) |  | 


