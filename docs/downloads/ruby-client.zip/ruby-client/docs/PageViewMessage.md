# SwaggerClient::PageViewMessage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**categories** | **Array&lt;String&gt;** |  | [optional] 
**phone_details** | [**PhoneDetails**](PhoneDetails.md) |  | 
**route_url** | **String** | Human readable unique routing Url for the page | 
**user_id** | **Integer** | Unique User Id of the logged in user. Any unique tracking ID for logged out user. | 
**tags** | **Array&lt;String&gt;** |  | [optional] 


