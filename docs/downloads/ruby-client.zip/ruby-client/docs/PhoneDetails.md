# SwaggerClient::PhoneDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**device_id** | **String** |  | [optional] 
**manufacturer** | **String** |  | [optional] 
**model** | **String** |  | [optional] 
**latitude** | **Float** |  | [optional] 
**longitude** | **Float** |  | [optional] 


