# SwaggerClient::ProductPageViewMessage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**product_id** | **Integer** | Unique Product ID of the product being viewed | 
**product_name** | **String** | Human understandable name of the product | 
**price** | **Float** | Price of the product | 


