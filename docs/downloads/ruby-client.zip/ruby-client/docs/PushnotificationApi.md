# SwaggerClient::PushnotificationApi

All URIs are relative to *http://127.0.0.1:8000/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**update_push_token_post**](PushnotificationApi.md#update_push_token_post) | **POST** /update_push_token/ | Update push token for a user device.


# **update_push_token_post**
> BeaconResponse update_push_token_post(body)

Update push token for a user device.

Use this to update the tokens necessary for push notifications. This is exposed as a set of 3 attributes - notification type, push token and push key. Notification type should be 0 for iOS notification and 1 for android. Push token could be the GCM registration token or the APNS registration token for the app device. Push key is your app&#39;s GCM key or APN key. Userid is optional. If userid is not speficied, the gcm token is stored without a userid. If a userid gets updated for a gcm token in future, another call needs to be made mentioning the userid.

### Example
```ruby
require 'swagger_client'

SwaggerClient.configure do |config|
  # Configure API key authorization: apikey
  config.api_key['apikey'] = "YOUR API KEY"
  # Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to nil)
  #config.api_key_prefix['apikey'] = "Token"
end

api = SwaggerClient::PushnotificationApi.new

body = SwaggerClient::UpdatePushToken.new # [UpdatePushToken] JSON object containing data


begin
  result = api.update_push_token_post(body)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling update_push_token_post: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**UpdatePushToken**](UpdatePushToken.md)| JSON object containing data | 

### Return type

[**BeaconResponse**](BeaconResponse.md)

### Authorization

[apikey](../README.md#apikey)

### HTTP reuqest headers

 - **Content-Type**: application/json
 - **Accept**: application/json



