# SwaggerClient::UpdatePushToken

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**user_id** | **Integer** | Unique User Id of the user. | [optional] 
**push_token** | **String** | Push Token for the user-device. This could be either the GCM Token or the APN Token | 
**push_key** | **String** | Your app&#39;s push notification key. This could be either your app&#39;s GCM key or your app&#39;s APN key. | [optional] 
**notification_type** | **Integer** | Set this to 1 for Android and 0 for iOS | 
**phone_details** | [**PhoneDetails**](PhoneDetails.md) |  | 


