(defproject octo-enterprise-api "1.0.0"
  :description "Integrate with Octo Enterprise using our RESTful APIs."
  :dependencies [[org.clojure/clojure "1.7.0"]
                 [clj-http "2.0.0"]
                 [cheshire "5.5.0"]])
