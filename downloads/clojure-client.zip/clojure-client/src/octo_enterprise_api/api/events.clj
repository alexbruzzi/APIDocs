(ns octo-enterprise-api.api.events
  (:require [octo-enterprise-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn events-app-init-post-with-http-info
  "Post an app init event.
  Event fired when app is initiated. Everytime app comes to foreground, this event should be fired with all possible values."
  [body ]
  (call-api "/events/app.init/" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    body
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["apikey"]}))

(defn events-app-init-post
  "Post an app init event.
  Event fired when app is initiated. Everytime app comes to foreground, this event should be fired with all possible values."
  [body ]
  (:data (events-app-init-post-with-http-info body)))

(defn events-app-login-post-with-http-info
  "Post an app login event.
  Event fired when user logins to the app"
  [body ]
  (call-api "/events/app.login/" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    body
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["apikey"]}))

(defn events-app-login-post
  "Post an app login event.
  Event fired when user logins to the app"
  [body ]
  (:data (events-app-login-post-with-http-info body)))

(defn events-app-logout-post-with-http-info
  "Post an app logout event.
  Event fired when user logs out of the app."
  [body ]
  (call-api "/events/app.logout/" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    body
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["apikey"]}))

(defn events-app-logout-post
  "Post an app logout event.
  Event fired when user logs out of the app."
  [body ]
  (:data (events-app-logout-post-with-http-info body)))

(defn events-page-view-post-with-http-info
  "Post a page view event.
  Event fired when a page view happened. You should fire this event on every page change in the viewport"
  [body ]
  (call-api "/events/page.view/" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    body
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["apikey"]}))

(defn events-page-view-post
  "Post a page view event.
  Event fired when a page view happened. You should fire this event on every page change in the viewport"
  [body ]
  (:data (events-page-view-post-with-http-info body)))

(defn events-productpage-view-post-with-http-info
  "Post a product page view event.
  Event fired when a product page view happened. You should fire this event on every page change in the viewport for products. Products are anything that the consumer consumes. It could cost them money or time. This cost is the value of 'price' parameter."
  [body ]
  (call-api "/events/productpage.view/" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    body
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["apikey"]}))

(defn events-productpage-view-post
  "Post a product page view event.
  Event fired when a product page view happened. You should fire this event on every page change in the viewport for products. Products are anything that the consumer consumes. It could cost them money or time. This cost is the value of 'price' parameter."
  [body ]
  (:data (events-productpage-view-post-with-http-info body)))
