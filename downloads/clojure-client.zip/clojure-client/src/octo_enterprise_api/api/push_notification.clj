(ns octo-enterprise-api.api.push-notification
  (:require [octo-enterprise-api.core :refer [call-api check-required-params with-collection-format]])
  (:import (java.io File)))

(defn update-push-token-post-with-http-info
  "Update push token for a user device.
  Use this to update the tokens necessary for push notifications. This is exposed as a set of 3 attributes - notification type, push token and push key. Notification type should be 0 for iOS notification and 1 for android. Push token could be the GCM registration token or the APNS registration token for the app device. Push key is your app's GCM key or APN key. Userid is optional. If userid is not speficied, the gcm token is stored without a userid. If a userid gets updated for a gcm token in future, another call needs to be made mentioning the userid."
  [body ]
  (call-api "/update_push_token/" :post
            {:path-params   {}
             :header-params {}
             :query-params  {}
             :form-params   {}
             :body-param    body
             :content-types ["application/json"]
             :accepts       ["application/json"]
             :auth-names    ["apikey"]}))

(defn update-push-token-post
  "Update push token for a user device.
  Use this to update the tokens necessary for push notifications. This is exposed as a set of 3 attributes - notification type, push token and push key. Notification type should be 0 for iOS notification and 1 for android. Push token could be the GCM registration token or the APNS registration token for the app device. Push key is your app's GCM key or APN key. Userid is optional. If userid is not speficied, the gcm token is stored without a userid. If a userid gets updated for a gcm token in future, another call needs to be made mentioning the userid."
  [body ]
  (:data (update-push-token-post-with-http-info body)))
